import './App.css'
import Weather from './components/weather/weather'

function App() {
  return (
    <div>
      <Weather />
    </div>
  )
}

export default App
